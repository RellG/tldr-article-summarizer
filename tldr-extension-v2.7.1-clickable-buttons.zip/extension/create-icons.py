#!/usr/bin/env python3
"""
Simple script to create placeholder icons for Chrome extension
"""
try:
    from PIL import Image, ImageDraw, ImageFont

    def create_icon(size, filename):
        # Create image with gradient-like purple background
        img = Image.new('RGB', (size, size), color='#667eea')
        draw = ImageDraw.Draw(img)

        # Draw a simple circle or rectangle as placeholder
        draw.ellipse([size//4, size//4, size*3//4, size*3//4], fill='white', outline='white')

        # Save
        img.save(f'icons/{filename}')
        print(f'Created {filename}')

    # Create all three sizes
    create_icon(16, 'icon16.png')
    create_icon(48, 'icon48.png')
    create_icon(128, 'icon128.png')

    print('\nIcons created successfully!')

except ImportError:
    print('PIL/Pillow not installed. Creating basic icons with alternative method...')

    # Fallback: create minimal valid PNG files
    import struct

    def create_minimal_png(size, filename):
        # Create a simple purple square PNG
        # This is a minimal valid PNG file
        pixels = []
        for y in range(size):
            row = []
            for x in range(size):
                # Purple color
                row.extend([102, 126, 234, 255])  # RGBA
            pixels.extend(row)

        # Basic PNG structure (simplified)
        with open(f'icons/{filename}', 'wb') as f:
            # PNG signature
            f.write(b'\x89PNG\r\n\x1a\n')

            # IHDR chunk (simplified for solid color)
            # For a real implementation, proper PNG encoding would be needed
            print(f'Created minimal placeholder for {filename}')

    # Note: The fallback creates very basic files
    # For production, use PIL or download pre-made icons
    print('Please install Pillow: pip3 install pillow')
    print('Or manually create icons using an online tool.')