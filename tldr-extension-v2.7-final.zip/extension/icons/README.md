# Extension Icons

Place your extension icons here:
- icon16.png (16x16px)
- icon48.png (48x48px)
- icon128.png (128x128px)

You can create icons using:
- Online tools like: https://www.favicon-generator.org/
- Design tools like Figma, Canva, or Photoshop
- AI image generators

Temporary placeholder icons will work for testing, but create proper icons for production.